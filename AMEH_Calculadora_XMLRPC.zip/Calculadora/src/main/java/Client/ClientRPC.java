package Client;

import Server.Operaciones;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;

import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfig;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class ClientRPC {
    ////Estrada hernádez Andrea Michelle 4°A
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) throws MalformedURLException {
        XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
        config.setServerURL(new URL("http://localhost:1200"));
        XmlRpcClient client = new XmlRpcClient();
        client.setConfig(config);
        String option = "", num1 ="", num2 = "";
        Operaciones op = new Operaciones();
        do {
            System.out.println("1. Suma");
            System.out.println("2. Resta");
            System.out.println("3. Multiplicacion");
            System.out.println("4. Division");
            System.out.println("5. Exponente");
            System.out.println("6. Raiz");
            System.out.println("7. Consultar Historial");
            System.out.println("8. Salir");
            System.out.println("Seleccione una opcion...");
            option = sc.next();
            System.out.println("");
            if(isNumber(option)){
                switch(Integer.parseInt(option)){
                    case 1: ///////////////////////////////////////////////////
                        System.out.println("********SUMA********");
                        do {
                            System.out.print("Ingrese el primer numero: ");
                            num1 = sc.next();
                             if (! isDouble(num1))
                                System.out.println("Número inválido, intente de nuevo...");
                        }while(! isDouble(num1));
                        do {
                            System.out.print("Ingrese el segundo numero: ");
                            num2 = sc.next();
                            if (! isDouble(num2))
                                System.out.println("Número inválido, intente de nuevo...");
                        }while(! isDouble(num2));
                        System.out.println("El resultado de la suma es: " + op.suma(num1, num2));
                        // Ejecucion del metodo en el servidor ...
                        break;

                    case 2: ///////////////////////////////////////////////////
                        System.out.println("********RESTA********");
                        do {
                            System.out.print("Ingrese el primer numero: ");
                            num1 = sc.next();
                            if (! isDouble(num1))
                                System.out.println("Número inválido, intente de nuevo...");
                        }while(! isDouble(num1));
                        do {
                            System.out.print("Ingrese el segundo numero: ");
                            num2 = sc.next();
                            if (! isDouble(num2))
                                System.out.println("Número inválido, intente de nuevo...");
                        }while(! isDouble(num2));
                        System.out.println("El resultado de la resta es: " + op.resta(num1, num2));
                        break;

                    case 3: ///////////////////////////////////////////////////
                        System.out.println("******** MULTIPLICACIÓN ********");
                        do {
                            System.out.print("Ingrese el primer numero: ");
                            num1 = sc.next();
                            if (! isDouble(num1))
                                System.out.println("Número inválido, intente de nuevo...");
                        }while(! isDouble(num1));
                        do {
                            System.out.print("Ingrese el segundo numero: ");
                            num2 = sc.next();
                            if (! isDouble(num2))
                                System.out.println("Número inválido, intente de nuevo...");
                        }while(! isDouble(num2));
                        System.out.println("El producto de la multiplicación es: " + op.mul(num1, num2));
                        break;
                    case 4: ///////////////////////////////////////////////////
                        System.out.println("******** DIVISIÓN ********");
                        do {
                            System.out.print("Ingrese el dividendo: ");
                            num1 = sc.next();
                            if (! isDouble(num1))
                                System.out.println("Número inválido, intente de nuevo...");
                        }while(! isDouble(num1));
                        do {
                            System.out.print("Ingrese el divisor: ");
                            num2 = sc.next();
                            if (! isDouble(num2))
                                System.out.println("Número inválido, intente de nuevo...");
                        }while(! isDouble(num2));
                        System.out.println("El resultado de la división es: " + op.div(num1, num2));
                        break;

                    case 5: ///////////////////////////////////////////////////
                        System.out.println("******** EXPONENTES ********");
                        do {
                            System.out.print("Ingrese la base(numero): ");
                            num1 = sc.next();
                            if (! isDouble(num1))
                                System.out.println("Número inválido, intente de nuevo...");
                        }while(! isDouble(num1));
                        do {
                            System.out.print("Ingrese exponente: ");
                            num2 = sc.next();
                            if (! isDouble(num2))
                                System.out.println("Número inválido, intente de nuevo...");
                        }while(! isDouble(num2));
                        System.out.println("El resultado es: " + op.exponente(num1, num2));
                        break;

                    case 6: ///////////////////////////////////////////////////
                        System.out.println("******** RAÍZ ********");
                        do {
                            System.out.print("Ingrese el  número: ");
                            num1 = sc.next();
                            if (! isDouble(num1))
                                System.out.println("Número inválido, intente de nuevo...");
                        }while(! isDouble(num1));

                        System.out.println("La raíz es: " + op.raiz(num1));
                        break;
                    case 7://///////////////////////
                        break;
                    case 8:
                        System.out.println("Saliendo :)");
                        break;
                    default:
                        System.out.println("No existe esta opcion");
                }
            }else{
                System.out.println("La opcion es incorrecta. Intente nuevamente");
            }
        }while (Integer.parseInt(option) !=8);
    }

    public static boolean isNumber (String number){
        try{
            Integer.parseInt(number);
            return true;
        }catch (NumberFormatException e){
            return false;
        }
    }
    public static boolean isDouble (String number){
        try{
            Double.parseDouble(number);
            return true;
        }catch (NumberFormatException e){
            return false;
        }
    }

}
