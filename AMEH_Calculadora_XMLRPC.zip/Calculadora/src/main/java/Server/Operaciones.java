package Server;

import java.util.Scanner;

public class Operaciones {
    ////Estrada hernádez Andrea Michelle 4°A
    private int num1,num2;
    static Scanner sc = new Scanner(System.in);

    public static int suma (String num1, String num2){
        int n1 = Integer.parseInt(num1);
        int n2 = Integer.parseInt(num2);
        int result = n1 + n2;
        return result;
    }
    public static int resta (String num1, String num2){
        int n1 = Integer.parseInt(num1);
        int n2 = Integer.parseInt(num2);
        int result = n1 - n2;
        return result;
    }
    public static int mul (String num1, String num2){
        int n1 = Integer.parseInt(num1);
        int n2 = Integer.parseInt(num2);
        int result = n1 * n2;
        return result;
    }

    public static double div (String num1, String num2){
        Double n1 = Double.parseDouble(num1);
        Double n2 = Double.parseDouble(num2);
        Double result = n1 / n2;
        return result;
    }

    public static int exponente (String num1, String num2){
        int n1 = Integer.parseInt(num1);
        int n2 = Integer.parseInt(num2);
        int result = (int) Math.pow(n1, n2);
        return result;
    }


    public static double raiz (String num1) {
        Double nv = Double.parseDouble(num1);
        double result = 0, conta;

        do {
            System.out.print("Número negativo, ingrese otro: ");
            nv = sc.nextDouble();
            if (nv>0){
                result = Math.sqrt(nv);
            }
            /*if (nv > 0) {
                result = Math.sqrt(nv);
            }else {
                System.out.println("no se aceptan numero negativos");
            }*/
        } while (nv < 0);

        //Double result =  Math.sqrt(Double.parseDouble(num1)) ;
        return result;
    }


}
