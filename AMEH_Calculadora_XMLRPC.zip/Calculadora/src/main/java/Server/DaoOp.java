package Server;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class DaoOp {
    ////Estrada hernádez Andrea Michelle 4°A
    Connection conn;
    PreparedStatement pstm;

    public String GET_OPERACIONES = "SELECT * FROM operaciones";

    public String INSERT_OPERA = "INSERT INTO operaciones(type, first_number, second_number, result, created_at) VALUES (?,?,?,?,?)";



}
